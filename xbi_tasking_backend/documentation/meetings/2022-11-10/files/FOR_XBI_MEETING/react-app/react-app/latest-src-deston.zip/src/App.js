import './App.css';

import '@fontsource/roboto/300.css';
import '@fontsource/roboto/400.css';
import '@fontsource/roboto/500.css';
import '@fontsource/roboto/700.css';

import TaskExplorer from './TaskExplorer.js'

import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import NavTabs from './NavTabs';

import TaskingManager2 from './TaskingManager2';
import TaskingSummary from './TaskingSummary';
import CompletedImages from './CompletedImages';


function App() {
  const tabs = [
    { label: 'Tasking Manager', to: '/', element: <TaskingManager2 /> },
    { label: 'Tasking Summary', to: '/tasking-summary', element: <TaskingSummary /> },
    { label: 'Completed Images', to: '/completed-images', element: <CompletedImages /> },
    { label: 'Task Explorer', to: '/task-explorer', element: <TaskExplorer /> }
  ]

  const currentTab = () => {
    let path = window.location.pathname;
    return tabs.findIndex((tab) => {
      // future improvement, if -1 then return 404 page index
      return tab.to === path;
    });
  };

  const title = "welcome to the new blog";
  const likes = 50;
  const person = { name: "deston", age: 30 }


  return (

    <Router>

      <div className="App">
        <NavTabs tabs={tabs} currentTab={currentTab} />
        <Routes>
          {tabs.map((route, index) => {
            return (
              <Route key={index} exact path={route.to} element={route.element} />
            )
          })}
        </Routes>
      </div>
    </Router>
  );
}

function Table() {
  return (
    <div className="Table">

    </div>
  );
}

export default App;

{/* <h2> { title }</h2>
<p>Liked {likes} times</p>
{ <p>hi {person}</p> }
<p> {10}, {"hello people"}, {[1,2,3,4,5]}, {Math.random() * 10}</p>  */}
